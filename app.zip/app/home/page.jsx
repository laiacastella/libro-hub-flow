"use client";

import {HomeInicio} from "@/components/HomeInicio/HomeInicio.jsx"; // El componente que me acabas de pasar

export default function PaginaPrincipal() {
    return (
        <>
            <main>
                <HomeInicio />
            </main>
        </>
    );
}