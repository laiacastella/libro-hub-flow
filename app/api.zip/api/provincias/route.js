import { db } from "@/lib/db";

export async function GET() {
    try {
        const [rows] = await db.query("SELECT id_provincia, provincia FROM provincias");
        return Response.json(rows);
    } catch (error) {
        return Response.json({ error: "Error BBDD" }, { status: 500 });
    }
}
